/**
 * Tests the correct initialisation of Random Data Provider Strategy.
 * Created by tedonema on 20/06/2015.
 */
package uk.co.jemos.podam.test.unit.features.dataProviderStrategy;