/**
 * Contains stories for using factories in Podam.
 *
 * Created by daivanov on 19/08/2016.
 *
 * @since 6.0.3
 */
package uk.co.jemos.podam.test.unit.features.factories;