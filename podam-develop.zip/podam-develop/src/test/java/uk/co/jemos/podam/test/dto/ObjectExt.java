/**
 *
 */
package uk.co.jemos.podam.test.dto;

/**
 * @author tedonema
 *
 */
public interface ObjectExt<T> {

	public T getValue();

	public void setValue(T value);

}
