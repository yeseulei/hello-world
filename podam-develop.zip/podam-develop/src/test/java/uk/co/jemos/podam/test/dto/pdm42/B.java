package uk.co.jemos.podam.test.dto.pdm42;

public class B extends C {

}
