/**
 * Contains tests to validate the Walk Through Example
 * Created by tedonema on 21/06/2015.
 */
package uk.co.jemos.podam.test.unit.features.walkThroughExample;